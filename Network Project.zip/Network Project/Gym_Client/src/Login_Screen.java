import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.RandomAccessFile;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.DataInputStream;
import java.io.DataOutputStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JTextArea;



public class Login_Screen extends JFrame implements ActionListener{
	public static Socket s;
	JLabel lblUsername;
	JLabel lblPassword;
	JLabel lblRegister;
	JTextField txtUsername;
	JPasswordField textPassword;
	JButton btnLogin;
	JButton btnRegister;
	
	public Login_Screen() 
	{
		this.setTitle("Login Page");
        this.setBounds(200, 200, 423, 305);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		JLabel lbl_Title = new JLabel("ESU Gym Check-In");
		lbl_Title.setFont(new Font("Tahoma", Font.BOLD, 16));
		lbl_Title.setBounds(126, 24, 158, 32);
		getContentPane().add(lbl_Title);
		
		lblUsername = new JLabel("Username: ");
		lblUsername.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblUsername.setBounds(82, 84, 90, 17);
		getContentPane().add(lblUsername);
		
		txtUsername = new JTextField();
		txtUsername.setBounds(184, 83, 140, 20);
		getContentPane().add(txtUsername);
		
		lblPassword = new JLabel("Password: ");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblPassword.setBounds(82, 116, 90, 17);
		getContentPane().add(lblPassword);
		
		textPassword = new JPasswordField();
		textPassword.setBounds(184, 115, 140, 20);
		getContentPane().add(textPassword);
		
		lblRegister = new JLabel("Need to register? ");
		lblRegister.setBounds(70, 207, 119, 17);
		getContentPane().add(lblRegister);
		
		btnLogin = new JButton("Login");
		btnLogin.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnLogin.setBounds(194, 156, 119, 32);
		btnLogin.addActionListener(this);
		getContentPane().add(btnLogin);
		
		btnRegister = new JButton("Click Here");
		btnRegister.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnRegister.setBounds(184, 199, 140, 32);
		btnRegister.addActionListener(this);
		getContentPane().add(btnRegister);

	    this.setVisible(true);
	    this.revalidate();
		
		
	}
	
	public static void main(String[] args) throws IOException
	{
		s = new Socket("localhost", 8788); // make it global variable
		
		new Login_Screen();
		
	}
	
	@Override
    public void actionPerformed(ActionEvent e) 
	{
        if (e.getSource().equals(btnLogin)) {
            try {
                processInfo1();

            } catch (UnknownHostException e1) {
                e1.printStackTrace();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
        else if (e.getSource().equals(btnRegister)) {
            try {
                processInfo2();

            } catch (UnknownHostException e2) {
                e2.printStackTrace();
            } catch (IOException e2) {
                e2.printStackTrace();
            }
        }
    }
	
	public void processInfo1() throws UnknownHostException, IOException 
	{

		
        DataInputStream dis = new DataInputStream(s.getInputStream()); 
        DataOutputStream dos = new DataOutputStream(s.getOutputStream());
        
        String name = txtUsername.getText();
        String password = String.valueOf(textPassword.getPassword());
        dos.writeUTF("Login: "+name+ " - "+password);
        boolean success = dis.readBoolean();
        
        if(!success)
        {
        	JOptionPane.showMessageDialog(null, "Invalid username or password");
        	
        	
        }
        else
        {
        	JOptionPane.showMessageDialog(null, "You are successfully logged in");
        	Schedule_Window window = new Schedule_Window();
        	//chooseGym window = new chooseGym();

        	window.setVisible(true);
        	this.setVisible(false);
        	
        }
    

    }
	
	public void processInfo2() throws UnknownHostException, IOException 
	{
		Register_Screen register = new Register_Screen();
		register.setVisible(true);
		this.setVisible(false);

    }
	
	
}
